package com.example.estudiante.opmeversion1;


import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseListAdapter;
import com.firebase.ui.database.FirebaseListOptions;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;


/**
 * A simple {@link Fragment} subclass.
 */
public class PerfilFragment extends Fragment {


    Button btn_cerrar;
    FirebaseDatabase db;
    Query ref;
    FirebaseListAdapter<Materia> adapter;
    ListView lv_materias;


    public PerfilFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view= inflater.inflate(R.layout.fragment_perfil, container, false);

        btn_cerrar = view.findViewById(R.id.btn_cerrar);
        lv_materias = view.findViewById(R.id.lv_materias);
        db=FirebaseDatabase.getInstance();

        ref = db.getReference().child("materias");
        //Lista de tareas

        FirebaseListOptions<Materia> options = new FirebaseListOptions.Builder<Materia>().setLayout(R.layout.renglon_materia).setQuery(ref,Materia.class).build();

        adapter=new FirebaseListAdapter<Materia>(options) {
            @Override
            protected void populateView(@NonNull View v, @NonNull final Materia model, int position) {



                TextView tv_nombre=v.findViewById(R.id.tv_nombre);
                TextView tv_puntaje=v.findViewById(R.id.tv_puntaje);


                tv_puntaje.setText(model.puntaje);
                tv_nombre.setText(model.nombre);


                if (model.nombre.equals("Algebra")) {
                    tv_puntaje.setBackgroundResource(R.drawable.circulo_algebra);
                    tv_puntaje.setTextColor(R.drawable.color_algebra);
                }
                if (model.nombre.equals("Logica")) {
                    tv_puntaje.setBackgroundResource(R.drawable.circulo_logica);

                    tv_puntaje.setTextColor(R.drawable.color_logica);
                }
                if (model.nombre.equals("COE")) {
                    tv_puntaje.setBackgroundResource(R.drawable.circulo_coe);
                    tv_puntaje.setTextColor(R.drawable.color_coe);
                }



            }
        };

//Añadir el adaptador a la lista

        lv_materias.setAdapter(adapter);

        btn_cerrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Materia m=new Materia();
                m.nombre="Logica";
                m.puntaje="80";

                db.getReference().child("materias").push().setValue(m);



                final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

                final View mView= getLayoutInflater().inflate(R.layout.alerta_mensaje, null);

                ImageView iv_carita = (ImageView) mView.findViewById(R.id.iv_carita);
                TextView tv_mensaje = (TextView) mView.findViewById(R.id.tv_msj_alerta);
                Button btn_negativo = mView.findViewById(R.id.btn_negativo);
                Button btn_positivo = mView.findViewById(R.id.btn_positivo);


               // builder.setCancelable(true);



                btn_positivo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(getActivity(), PantallaLogin.class);
                        startActivity(intent);
                    }
                });



                builder.setView(mView);
                final AlertDialog alert = builder.create();
                alert.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                alert.show();


                btn_negativo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alert.dismiss();
                    }
                });


            }
        });

        // Inflate the layout for this fragment
        return view;





    }

    @Override
    public void onStart() {
        super.onStart();

        //iniciar adaptador
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }


}
