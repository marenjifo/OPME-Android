package com.example.estudiante.opmeversion1;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.NumberPicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;

public class Recordatorio extends AppCompatActivity implements DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener, View.OnClickListener ,AdapterView.OnItemSelectedListener{

    EditText et_nombreAct;
    Spinner sp_materia;
    ImageButton btn_libro,btn_video,btn_taller;
    Button btn_fecha;
    Button btn_agregar;
    Button btn_duracion;
    ImageButton btn_salir;
    Typeface robotoBold,robotoRegular;
    TextView tv_titulo,tv_materia,tv_tipo,tv_fecha,tv_duracion;
    int boton;
    float selectedFloat=0;



    //Para fecha y hora
    int dia, mes, year, hora, min;
    int diaFinal, mesFinal, yearFinal,horaFinal, minFinal;
    String AM_PM ;

    //Database
    FirebaseDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recordatorio);

        robotoBold= Typeface.createFromAsset(getAssets(), "Fonts/robotoBold.ttf");
        robotoRegular= Typeface.createFromAsset(getAssets(), "Fonts/robotoRegular.ttf");
        //Referencias elementos XML
        et_nombreAct=findViewById(R.id.et_nombreAct);
        sp_materia=findViewById(R.id.sp_materia);
        btn_libro=findViewById(R.id.btn_libro);
        btn_video=findViewById(R.id.btn_video);
        btn_taller=findViewById(R.id.btn_taller);
        btn_fecha=findViewById(R.id.btn_fecha);
        btn_agregar=findViewById(R.id.btn_agregar);
        btn_duracion=findViewById(R.id.btn_duracion);
        tv_titulo=findViewById(R.id.tv_titulo);
        tv_materia=findViewById(R.id.tv_nombre);
        tv_tipo=findViewById(R.id.tv_tipo);
        tv_duracion=findViewById(R.id.tv_duracion);
        tv_fecha=findViewById(R.id.tv_fecha);
       btn_salir=findViewById(R.id.btn_salir);
        //Tipografias
        et_nombreAct.setTypeface(robotoRegular);
        btn_fecha.setTypeface(robotoRegular);
        btn_agregar.setTypeface(robotoBold);
        tv_titulo.setTypeface(robotoBold);
//        tv_materia.setTypeface(robotoBold);
        tv_tipo.setTypeface(robotoBold);
        tv_duracion.setTypeface(robotoBold);
        tv_fecha.setTypeface(robotoBold);

        //ESCOGER MATERIA
        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(this,R.array.Materias,R.layout.spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_materia.setAdapter(adapter);
        sp_materia.setOnItemSelectedListener(this);

        //ESCOGER TIPO DE ACTIVIDAD

        View.OnClickListener listener = new View.OnClickListener()
        {

            @Override
            public void onClick(View v)
            {
                switch (v.getId()){
                    case R.id.btn_libro:
                        btn_libro.setBackgroundResource(R.drawable.libro_recor_s);
                        btn_video.setBackgroundResource(R.drawable.boton_video_recor);
                        btn_taller.setBackgroundResource(R.drawable.boton_taller_recor);
                        boton=1;
                        break;

                    case R.id.btn_video:
                        btn_video.setBackgroundResource(R.drawable.video_recor_s);
                        btn_taller.setBackgroundResource(R.drawable.boton_taller_recor);
                        btn_libro.setBackgroundResource(R.drawable.boton_libro_recor);
                        boton=2;

                        break;

                    case R.id.btn_taller:
                        btn_taller.setBackgroundResource(R.drawable.taller_recor_s);
                        btn_video.setBackgroundResource(R.drawable.boton_video_recor);
                        btn_libro.setBackgroundResource(R.drawable.boton_libro_recor);
                        boton=3;

                        break;
                }





            }
        };

        btn_libro.setOnClickListener(listener);
        btn_video.setOnClickListener(listener);
        btn_taller.setOnClickListener(listener);


        //PARA ESCOGER FECHA Y HORA

        btn_fecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar c=Calendar.getInstance();
                year=c.get(Calendar.YEAR);
                mes=c.get(Calendar.MONTH);
                dia=c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog=new DatePickerDialog(Recordatorio.this,Recordatorio.this,year,mes,dia);
                datePickerDialog.show();
            }
        });

        //PARA ESCOGER DURACION DE TAREA
        btn_duracion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final NumberPicker numberPicker=new NumberPicker(Recordatorio.this);
                final String nums[]={"0.5","1","1.5","2","2.5","3","3.5","4","4.5","5","5.5","6","6.5","7"};
                numberPicker.setMaxValue(nums.length-1);
                numberPicker.setMinValue(0);
                numberPicker.setDisplayedValues(nums);

                NumberPicker.OnValueChangeListener valueChangeListener=new NumberPicker.OnValueChangeListener() {
                    @Override
                    public void onValueChange(NumberPicker picker, int oldVal, int newVal) {

                        int index = numberPicker.getValue();
                        final String val = nums[index];
                        selectedFloat = Float.parseFloat(val);

                        btn_duracion.setText(selectedFloat+"  horas");
                    }
                };
                numberPicker.setOnValueChangedListener(valueChangeListener);
                AlertDialog.Builder builder=new AlertDialog.Builder(Recordatorio.this).setView(numberPicker);
                builder.setTitle("Duracion de tarea").setIcon(R.mipmap.ic_launcher);
                builder.setPositiveButton("ACEPTAR", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                builder.setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
            }
        });

        db=FirebaseDatabase.getInstance();

        btn_agregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Recor nuevo_recor=new Recor();

                //Datos se extraen de EditText (.getText)
                nuevo_recor.nombre=et_nombreAct.getText().toString();
                nuevo_recor.materia=sp_materia.getSelectedItem().toString();
                switch (boton){
                    case 1:
                        nuevo_recor.tipo="Lectura";
                        break;
                    case 2:
                        nuevo_recor.tipo="Video";
                        break;
                    case 3:
                        nuevo_recor.tipo="Taller";
                        break;
                }
                nuevo_recor.fecha=yearFinal+"-"+mesFinal+"-"+diaFinal;
                if(minFinal<10) {
                    nuevo_recor.hora = horaFinal + ":" + "0" + minFinal+" "+AM_PM;
                }else{ nuevo_recor.hora=horaFinal + ":" + minFinal+""+AM_PM;
                }
                nuevo_recor.duracion=""+selectedFloat;

                db.getReference().child("recordatorios").push().setValue(nuevo_recor);

                //Resetear
                et_nombreAct.setText(null);
                boton=0;
                btn_duracion.setText("seleccionar");
                btn_fecha.setText("seleccionar");

                Intent intent= new Intent(Recordatorio.this,PantallaPrincipal.class);
                startActivity(intent);



            }
        });

        btn_salir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Recordatorio.this,PantallaPrincipal.class);
                startActivity(i);
            }
        });



    }

    @Override
    public void onDateSet(DatePicker view, int i, int i1, int i2) {
        yearFinal=i;
        mesFinal=i1+1;
        diaFinal=i2;

        Calendar c=Calendar.getInstance();
        hora=c.get(Calendar.HOUR_OF_DAY);
        min=c.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog=new TimePickerDialog(Recordatorio.this,this,hora,min, android.text.format.DateFormat.is24HourFormat(Recordatorio.this));
        timePickerDialog.show();
    }

    @Override
    public void onTimeSet(TimePicker view, int i, int i1) {
        horaFinal=i;
        minFinal=i1;

        if(horaFinal < 12) {
            AM_PM = "AM";
        } else {
            AM_PM = "PM";
        }

        if(minFinal<10) {
            btn_fecha.setText(diaFinal + "/" + mesFinal + "/" + yearFinal + " - " + horaFinal + ":" + "0"+minFinal + " " + AM_PM);
        }else{
            btn_fecha.setText(diaFinal + "/" + mesFinal + "/" + yearFinal + " - " + horaFinal + ":" + minFinal + " " + AM_PM);
        }
    }


    @Override
    public void onClick(View v) {



    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String mat=parent.getItemAtPosition(position).toString();
        //Toast.makeText(parent.getContext(),mat,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


    public void setFragment(Fragment fragment) {
        FragmentTransaction fragmentTransaction= getSupportFragmentManager().beginTransaction();

        fragmentTransaction.replace(R.id.ac_recordatorio,fragment);
        fragmentTransaction.commit();
    }

}
