package com.example.estudiante.opmeversion1;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Pregunta extends AppCompatActivity {

    private Libreria libreria;
    FirebaseDatabase db;
    DatabaseReference query;
    String ref;

    private TextView nPreguntaView;
    private Button btn_opcion1;
    private Button btn_opcion2;
    private Button btn_opcion3;
    private Button btn_terminar;
    private Button btn_x;

    private String respuesta;
    private int nScore=0;
    private int numeroRespuestas=0;
    int numero=1;


    TextView tv_nombre;
    String nombre;
    TextView tv_pregunta;
    TextView tv_numPregunta;




    Typeface robotoBold,robotoRegular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pregunta);

        robotoBold= Typeface.createFromAsset(this.getAssets(), "Fonts/robotoBold.ttf");
        robotoRegular= Typeface.createFromAsset(this.getAssets(), "Fonts/robotoRegular.ttf");

        tv_nombre=findViewById(R.id.tv_nombre);

        tv_pregunta=findViewById(R.id.tv_pregunta);
        tv_numPregunta=findViewById(R.id.tv_numPregunta);



        nPreguntaView = (TextView)findViewById(R.id.tv_pregunta);
        btn_opcion1=findViewById(R.id.btn_opcion1);
        btn_opcion2=findViewById(R.id.btn_opcion2);
        btn_opcion3=findViewById(R.id.btn_opcion3);
        btn_terminar=findViewById(R.id.btn_terminar);
        btn_x=findViewById(R.id.btn_x);


        tv_nombre.setTypeface(robotoBold);
        nombre = getIntent().getStringExtra("nombre");
        tv_nombre.setText(nombre);
        tv_pregunta.setTypeface(robotoRegular);
        tv_numPregunta.setTypeface(robotoBold);
        tv_numPregunta.setText(""+numero);


        btn_opcion1.setTypeface(robotoRegular);
        btn_opcion2.setTypeface(robotoRegular);
        btn_opcion3.setTypeface(robotoRegular);

        libreria = new Libreria();






        btn_opcion1. setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btn_opcion1.setBackground(ContextCompat.getDrawable(Pregunta.this, R.drawable.boton_seleccionado));
                btn_opcion2.setBackground(ContextCompat.getDrawable(Pregunta.this, R.drawable.boton_opciones));
                btn_opcion3.setBackground(ContextCompat.getDrawable(Pregunta.this, R.drawable.boton_opciones));

                btn_terminar.setBackground(ContextCompat.getDrawable(Pregunta.this, R.drawable.boton_siguiente_activo));
                if(btn_opcion1.getText()==respuesta){
                    nScore = nScore+1;

                    Toast.makeText(Pregunta.this,"Correcto",Toast.LENGTH_SHORT).show();

                }
            }


        });

        btn_opcion2. setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btn_opcion2.setBackground(ContextCompat.getDrawable(Pregunta.this, R.drawable.boton_seleccionado));
                btn_opcion3.setBackground(ContextCompat.getDrawable(Pregunta.this, R.drawable.boton_opciones));
                btn_opcion1.setBackground(ContextCompat.getDrawable(Pregunta.this, R.drawable.boton_opciones));

                btn_terminar.setBackground(ContextCompat.getDrawable(Pregunta.this, R.drawable.boton_siguiente_activo));
                if(btn_opcion2.getText()==respuesta){
                    nScore = nScore+1;

                    Toast.makeText(Pregunta.this,"Correcto",Toast.LENGTH_SHORT).show();

                }
            }


        });

        btn_opcion3. setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btn_opcion3.setBackground(ContextCompat.getDrawable(Pregunta.this, R.drawable.boton_seleccionado));
                btn_opcion2.setBackground(ContextCompat.getDrawable(Pregunta.this, R.drawable.boton_opciones));
                btn_opcion1.setBackground(ContextCompat.getDrawable(Pregunta.this, R.drawable.boton_opciones));
                btn_terminar.setBackground(ContextCompat.getDrawable(Pregunta.this, R.drawable.boton_siguiente_activo));

                if(btn_opcion3.getText()==respuesta){
                    nScore = nScore+1;

                    Toast.makeText(Pregunta.this,"Correcto",Toast.LENGTH_SHORT).show();

                }
            }


        });

        btn_terminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              numero+=1;
                updatePreguntas();
                btn_opcion3.setBackground(ContextCompat.getDrawable(Pregunta.this, R.drawable.boton_opciones));
                btn_opcion1.setBackground(ContextCompat.getDrawable(Pregunta.this, R.drawable.boton_opciones));
                btn_opcion2.setBackground(ContextCompat.getDrawable(Pregunta.this, R.drawable.boton_opciones));

                btn_terminar.setBackground(ContextCompat.getDrawable(Pregunta.this, R.drawable.boton_siguiente));

            }
        });

        btn_x.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Pregunta.this);

                View mView= getLayoutInflater().inflate(R.layout.alerta_mensaje, null);

                ImageView iv_carita = (ImageView) mView.findViewById(R.id.iv_carita);
                TextView tv_mensaje = (TextView) mView.findViewById(R.id.tv_msj_alerta);
                Button btn_negativo = mView.findViewById(R.id.btn_negativo);
                Button btn_positivo = mView.findViewById(R.id.btn_positivo);


                iv_carita.setImageResource(R.drawable.carita_triste);
                tv_mensaje.setText("Deseas salir del cuestionario? \nObtendrás 0 puntos");
                btn_negativo.setText("Cancelar");
                btn_positivo.setText("Salir");


                builder.setView(mView);
                final AlertDialog alert = builder.create();
                alert.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                alert.show();


                btn_positivo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Intent i = new Intent(Pregunta.this,Actividad.class);
                        startActivity(i);
                        finish();
                        alert.dismiss();


                    }
                });
                btn_negativo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alert.dismiss();
                    }
                });

            }
        });


    }


    private void updatePreguntas(){
        if(numeroRespuestas<2){
            numeroRespuestas+=1;
            numero+=1;

            nPreguntaView.setText(libreria.getPregunta(numeroRespuestas));
            btn_opcion1.setText(libreria.getOpcion1(numeroRespuestas));
            btn_opcion2.setText(libreria.getOpcion2(numeroRespuestas));
            btn_opcion3.setText(libreria.getOpcion3(numeroRespuestas));

            respuesta = libreria.getCorrecta(numeroRespuestas);
        }
        if(numeroRespuestas==2){
            btn_terminar.setText("Finalizar");
            btn_terminar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent i =new Intent(Pregunta.this, Puntaje.class);
                    i.putExtra("score",nScore);
                    startActivity(i);

                }
            });
        }

    }


}