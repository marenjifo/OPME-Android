package com.example.estudiante.opmeversion1;


import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


/**
 * A simple {@link Fragment} subclass.
 */
public class CalendarioFragment extends Fragment {

    private static final String TAG = "CalendarioFragment";
    private TabAdapter tabAdapter;
    private  ViewPager viewPager;
    private TextView tv_num;
    FirebaseDatabase db;

    public CalendarioFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.fragment_calendario, container, false);

        tabAdapter=new TabAdapter(getChildFragmentManager());
        viewPager=view.findViewById(R.id.container);

        setupViewPager(viewPager);

        db=FirebaseDatabase.getInstance();

        TabLayout tabLayout=view.findViewById(R.id.tabLayout);
        tabLayout.setupWithViewPager(viewPager);

        tv_num=view.findViewById(R.id.tv_num);


        db.getReference().child("tareas").addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange (DataSnapshot dataSnapshot) {

                int suma=0;
                int total=0;

                for (DataSnapshot dato : dataSnapshot.getChildren()) {
                    // parse the snapshot to your local model
                    Tarea tarea = dato.getValue(Tarea.class);

                    // access your desired field
                    String duracion = tarea.duracion;
                    int valor=Integer.parseInt(duracion);
                    total= suma+=valor;

                    Log.e("DURACION",duracion);
                    Log.e("Total",""+total);
                    tv_num.setText(""+total);
                }
            }

            @Override
            public void onCancelled (DatabaseError databaseError) {

            }
        });

        // Inflate the layout for this fragment
        return view;




    }

    private void setupViewPager(ViewPager viewPager){
        TabAdapter adapter=new TabAdapter(getChildFragmentManager());
        adapter.addFragment(new Tarea_Fragment(),"LISTA DE TAREAS");
        adapter.addFragment(new RecorFragment(),"RECORDATORIOS");
        viewPager.setAdapter(adapter);

    }


}
