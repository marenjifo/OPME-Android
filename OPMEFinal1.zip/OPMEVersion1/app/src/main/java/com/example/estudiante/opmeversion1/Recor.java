package com.example.estudiante.opmeversion1;

public class Recor {

    public String nombre;
    public String tipo;
    public String materia;
    public String fecha;
    public String hora;
    public String duracion;


    public Recor(){

    }

}

