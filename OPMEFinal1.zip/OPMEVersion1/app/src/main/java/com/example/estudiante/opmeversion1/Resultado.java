package com.example.estudiante.opmeversion1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class Resultado extends AppCompatActivity {

    private int scoreFinal;
    private TextView tv_score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);

        tv_score=findViewById(R.id.tv_score);
        scoreFinal= getIntent().getIntExtra("score",0);
        tv_score.setText(scoreFinal+"");

    }
}
