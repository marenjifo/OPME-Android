package com.example.estudiante.opmeversion1;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.FirebaseDatabase;

public class Actividad extends AppCompatActivity {


    TextView tv_nombre;
    TextView tv_materia;
    TextView tv_hora;
    TextView tv_fecha;
    TextView tv_descripcion;
    Chronometer crono;
    TextView tv_tipo;
    TextView tv_duracion;
    TextView tv_descrip;
    String ref;
    long pauseOffset;
    boolean activado;

    private FirebaseDatabase db;

    Button btn_terminar;
    ImageButton btn_iniciar;
    Button btn_pause;
    ImageButton btn_pausa;
    Button btn_x;

    ImageView im_tipo;
    ImageView im_enlace;
    ImageView im_cuestionario;

    Typeface robotoBold,robotoRegular;

    //Datos de listView
    public String nombre;
    public String tipo;
    public String materia;
    public String fecha;
    public String hora;
    public String duracion;
    public String[] preguntas;
    public String[] opciones;
    public String[] respuestas;
    public String enlace;
    public String descripcion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad);

        db=FirebaseDatabase.getInstance();

        robotoBold= Typeface.createFromAsset(this.getAssets(), "Fonts/robotoBold.ttf");
        robotoRegular= Typeface.createFromAsset(this.getAssets(), "Fonts/robotoRegular.ttf");

        tv_nombre=findViewById(R.id.tv_nombre);
        tv_materia=findViewById(R.id.tv_nombre);
        tv_hora=findViewById(R.id.tv_hora);
        tv_fecha=findViewById(R.id.tv_fecha);
        tv_descripcion=findViewById(R.id.tv_descripcion);
        crono=findViewById(R.id.crono);
        tv_tipo=findViewById(R.id.tv_tipo);
        tv_duracion=findViewById(R.id.tv_duracion);
        im_cuestionario=findViewById(R.id.im_cuestionrio);
        tv_descrip=findViewById(R.id.tv_descrip);


        btn_terminar=findViewById(R.id.btn_terminar);
        btn_pausa=findViewById(R.id.btn_pausa);
        btn_x=findViewById(R.id.btn_x);
        btn_iniciar=findViewById(R.id.btn_iniciar);

        im_tipo=findViewById(R.id.im_tipo);
        im_enlace=findViewById(R.id.im_enlace);

        tv_nombre.setTypeface(robotoBold);
        tv_materia.setTypeface(robotoRegular);
        tv_hora.setTypeface(robotoRegular);
        tv_fecha.setTypeface(robotoRegular);
        tv_descripcion.setTypeface(robotoRegular);
        crono.setTypeface(robotoRegular);
        tv_tipo.setTypeface(robotoRegular);
        tv_descrip.setTypeface(robotoBold);


        crono.setBase(SystemClock.elapsedRealtime());


        btn_terminar.setTypeface(robotoRegular);

        nombre = getIntent().getStringExtra("nombre");
        tv_nombre.setText(nombre);

        fecha=getIntent().getStringExtra("fecha");
        tv_fecha.setText(fecha);

        hora=getIntent().getStringExtra("hora");
        tv_hora.setText(hora);

        duracion=getIntent().getStringExtra("duracion");
        tv_duracion.setText(duracion+" horas");

        descripcion=getIntent().getStringExtra("descripcion");
        tv_descripcion.setText(descripcion);

        materia=getIntent().getStringExtra("materia");
        tv_materia.setText(materia);


        tipo=getIntent().getStringExtra("tipo");
        //Log.e("ERROR",tipo);
        if(tipo!=null) {
            if (tipo.equals("Lectura")) {
                im_tipo.setImageResource(R.drawable.enca_act_l);
                im_enlace.setImageResource(R.drawable.boton_libro);
                tv_tipo.setText("Ver lectura");

            } else if (tipo.equals("Video")) {
                im_tipo.setImageResource(R.drawable.enca_act_v);
                im_enlace.setImageResource(R.drawable.boton_video);
                tv_tipo.setText("Ver video");

            } else if (tipo.equals("Taller")) {
                im_tipo.setImageResource(R.drawable.enca_act_t);
                im_enlace.setImageResource(R.drawable.boton_taller);
                tv_tipo.setText("Ver taller");

            }

        }
        enlace=getIntent().getStringExtra("enlace");
        ref=getIntent().getStringExtra("ref");
        im_enlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(Actividad.this);

                View mView= getLayoutInflater().inflate(R.layout.alerta_mensaje, null);

                ImageView iv_carita = (ImageView) mView.findViewById(R.id.iv_carita);
                TextView tv_mensaje = (TextView) mView.findViewById(R.id.tv_msj_alerta);
                Button btn_negativo = mView.findViewById(R.id.btn_negativo);
                Button btn_positivo = mView.findViewById(R.id.btn_positivo);


                iv_carita.setImageResource(R.drawable.carita_feliz);
                tv_mensaje.setText("Deseas comenzar la tarea? \nTu tiempo será cronometrado");
                btn_negativo.setText("Cancelar");
                btn_positivo.setText("Comenzar");




                builder.setView(mView);
                final AlertDialog alert = builder.create();
                alert.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                alert.show();


                btn_positivo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if(enlace!=null){
                            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(enlace));
                            startActivity(browserIntent);
                            alert.dismiss();
                        }

                    }
                });
                btn_negativo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alert.dismiss();
                    }
                });
            }
        });


        im_cuestionario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Actividad.this);

                View mView= getLayoutInflater().inflate(R.layout.alerta_mensaje, null);

                ImageView iv_carita = (ImageView) mView.findViewById(R.id.iv_carita);
                TextView tv_mensaje = (TextView) mView.findViewById(R.id.tv_msj_alerta);
                Button btn_negativo = mView.findViewById(R.id.btn_negativo);
                Button btn_positivo = mView.findViewById(R.id.btn_positivo);


                iv_carita.setImageResource(R.drawable.carita_tranqui);
                tv_mensaje.setText("Deseas realizar el cuestionario? \nTendrás un intento para hacerlo ");
                btn_negativo.setText("Cancelar");
                btn_positivo.setText("Comenzar");




                builder.setView(mView);
                final AlertDialog alert = builder.create();
                alert.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                alert.show();


                btn_positivo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                            Intent intent = new Intent(Actividad.this,Pregunta.class);
                            intent.putExtra("ref",ref);
                            intent.putExtra("nombre",nombre);
                            startActivity(intent);
                            alert.dismiss();


                    }
                });
                btn_negativo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alert.dismiss();
                    }
                });
            }
        });

        btn_x.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i= new Intent(Actividad.this,PantallaPrincipal.class);
                startActivity(i);
                finish();
            }
        });

        btn_terminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Actividad.this);

                View mView= getLayoutInflater().inflate(R.layout.alerta_mensaje, null);

                ImageView iv_carita = (ImageView) mView.findViewById(R.id.iv_carita);
                TextView tv_mensaje = (TextView) mView.findViewById(R.id.tv_msj_alerta);
                Button btn_negativo = mView.findViewById(R.id.btn_negativo);
                Button btn_positivo = mView.findViewById(R.id.btn_positivo);


                iv_carita.setImageResource(R.drawable.carita_tranqui);
                tv_mensaje.setText("Estas seguro que has \nterminado toda la tarea");
                btn_negativo.setText("Cancelar");
                btn_positivo.setText("Confirmar");




                builder.setView(mView);
                final AlertDialog alert = builder.create();
                alert.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                alert.show();


                btn_positivo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Intent intent = new Intent(Actividad.this,PantallaPrincipal.class);
                        startActivity(intent);
                        alert.dismiss();
                        terminarCrono();


                        Log.e("LLEGO",ref);


                        db.getReference("tareas/"+ref+"/completado").setValue("si");




                    }
                });


                btn_negativo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alert.dismiss();
                    }
                });
            }
        });


        btn_iniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                comenzarCrono();
            }
        });

        btn_pausa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pausarCrono();
            }
        });

    }

    public void comenzarCrono(){
        if(!activado){
            crono.setBase(SystemClock.elapsedRealtime()-pauseOffset);
            crono.start();
            activado=true;
        }
    }

    public void pausarCrono(){
        if(activado){
            crono.stop();
            pauseOffset=SystemClock.elapsedRealtime()-crono.getBase();
            activado=false;

        }

    }

    public void terminarCrono(){
        crono.setBase(SystemClock.elapsedRealtime());
        pauseOffset=0;

    }

    public static Intent createIntent(Context context) {
        Intent i = new Intent(context, Puntaje.class);
        i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        return i;
    }


}

