package com.example.estudiante.opmeversion1;

public class Libreria {

    private String nPreguntas[] ={


            "pregunta1","pregunta2", "pregunta3"
    };

    private String nOpciones [][] = {
            {"a", "b", "c"},
            {"d", "f", "g"},
            {"h", "i", "j"}
    };

    private String nCorrectas [] ={
            "a","d","h"
    };

    public String getPregunta(int a){
        String pregunta= nPreguntas[a];
        return pregunta;
    }




    public String getOpcion1(int a){
        String opcion0= nOpciones[a][0];
        return opcion0;
    }

    public String getOpcion2(int a){
        String opcion1= nOpciones[a][1];
        return opcion1;
    }
    public String getOpcion3(int a){
        String opcion2= nOpciones[a][2];
        return opcion2;
    }

    public String getCorrecta(int a){
        String correcta= nCorrectas[a];
        return correcta;
    }





}