package com.example.estudiante.opmeversion1;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;


public class PantallaPrincipal extends AppCompatActivity {

    private BottomNavigationView navBar;
    private FrameLayout fragment;

    private CalendarioFragment calendarioFragment;
    private PerfilFragment perfilFragment;
    private FloatingActionButton fb_recor;
    private Recordatorio recordatorio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_principal);

        navBar = findViewById(R.id.nav_bar);
        fragment = findViewById(R.id.calendario_layaout);
        fb_recor=findViewById(R.id.fb_recor);
        recordatorio=new Recordatorio();

        calendarioFragment= new CalendarioFragment();

        perfilFragment= new PerfilFragment();

        setFragment(calendarioFragment);

        navBar.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {



                switch (menuItem.getItemId()){

                    case R.id.btn_calendario:

                            setFragment(calendarioFragment);
                        break;

                    case R.id.btn_perfil:

                        setFragment(perfilFragment);
                        break;

                        default:
                            break;

                }



                return  true;
            }

            private void setFragment(Fragment fragment) {
                FragmentTransaction fragmentTransaction= getSupportFragmentManager().beginTransaction();

                fragmentTransaction.replace(R.id.calendario_layaout,fragment);
                fragmentTransaction.commit();
            }


        });

        fb_recor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //setFragment(recordatorio);
                Intent i =new Intent(PantallaPrincipal.this,Recordatorio.class);
                startActivity(i);
            }
        });


    }

    public void setFragment(Fragment fragment) {
        FragmentTransaction fragmentTransaction= getSupportFragmentManager().beginTransaction();

        fragmentTransaction.replace(R.id.calendario_layaout,fragment);
        fragmentTransaction.commit();
    }


}
