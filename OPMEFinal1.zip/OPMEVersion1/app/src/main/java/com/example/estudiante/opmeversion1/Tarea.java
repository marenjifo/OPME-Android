package com.example.estudiante.opmeversion1;

public class Tarea {

    public String nombre;
    public String tipo;
    public String materia;
    public String fecha;
    public String hora;
    public String duracion;
    public String[] preguntas;
    public String [] opciones;
    public  String [] respuestas;
    public String enlace;
    public String descripcion;
    public String completado;

    public Tarea(){

    }

}
