package com.example.estudiante.opmeversion1;

public class Materia {

    String puntaje;
    String nombre;

    public Materia(){

    }
}
