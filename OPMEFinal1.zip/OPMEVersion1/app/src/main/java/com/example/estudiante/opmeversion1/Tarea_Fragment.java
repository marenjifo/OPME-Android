package com.example.estudiante.opmeversion1;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseListAdapter;
import com.firebase.ui.database.FirebaseListOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public class Tarea_Fragment extends Fragment implements AdapterView.OnItemSelectedListener{

    private static final String TAG = "Tarea_Fragment";
    private FirebaseDatabase db;
    private ListView lv_tareas;

    String ordenar;
    int filtro;
    Query ref;
    FirebaseListAdapter<Tarea> adapter;
    Typeface robotoBold,robotoRegular;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {



        View view=inflater.inflate(R.layout.fragment_tarea, container, false);
        db=FirebaseDatabase.getInstance();
        lv_tareas=view.findViewById(R.id.lv_tareas);






        ref = db.getReference().child("tareas").orderByChild("materia");
        //Lista de tareas

        FirebaseListOptions<Tarea> options = new FirebaseListOptions.Builder<Tarea>().setLayout(R.layout.renglon_tarea).setQuery(ref,Tarea.class).build();

        adapter=new FirebaseListAdapter<Tarea>(options) {
            @Override
            protected void populateView(@NonNull View v, @NonNull final Tarea model, int position) {

                ImageView iv_icon_tarea=v.findViewById(R.id.iv_icon_tarea);
                TextView tv_nombre=v.findViewById(R.id.tv_nombre);
                TextView tv_materia=v.findViewById(R.id.tv_materia);
                TextView tv_color=v.findViewById(R.id.tv_color);
                TextView tv_fecha=v.findViewById(R.id.tv_fecha);
                TextView tv_hora=v.findViewById(R.id.tv_hora);
                TextView tv_duracion=v.findViewById(R.id.tv_duracion);

                tv_nombre.setText(model.nombre);
                tv_materia.setText(model.materia);
                tv_fecha.setText(model.fecha);
                tv_hora.setText(model.hora);
                tv_duracion.setText(model.duracion+" horas");

                if(model.completado.equals("no")) {

                    if (model.tipo.equals("Lectura")) {
                        iv_icon_tarea.setImageResource(R.drawable.libro_tareas);
                    }
                    if (model.tipo.equals("Video")) {
                        iv_icon_tarea.setImageResource(R.drawable.video_tareas);
                    }
                    if (model.tipo.equals("Taller")) {
                        iv_icon_tarea.setImageResource(R.drawable.taller_tareas);
                    }
                    if (model.materia.equals("Algebra")) {
                        tv_color.setBackgroundResource(R.drawable.color_algebra);
                    }
                    if (model.materia.equals("Logica")) {
                        tv_color.setBackgroundResource(R.drawable.color_logica);
                    }
                    if (model.materia.equals("COE")) {
                        tv_color.setBackgroundResource(R.drawable.color_coe);
                    }
                }else{
                  iv_icon_tarea.setImageResource(R.drawable.check);
                }

                lv_tareas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        DatabaseReference ref= adapter.getRef(position);
                        String ref2= ref.getKey();
                        Log.e("REF",ref2);

                        //Pasar de fragmento a activity
                        Intent i =new Intent(getActivity(),Actividad.class);
                        i.putExtra("nombre",model.nombre);
                        i.putExtra("materia",model.materia);
                        i.putExtra("duracion",model.duracion);
                        i.putExtra("fecha",model.fecha);
                        i.putExtra("hora",model.hora);
                        i.putExtra("enlace",model.enlace);
                        i.putExtra("descripcion",model.descripcion);
                        i.putExtra("tipo",model.tipo);
                        i.putExtra("ref",ref2);


                        startActivity(i);
                    }
                });


            }
        };

//Añadir el adaptador a la lista

        lv_tareas.setAdapter(adapter);



        // Inflate the layout for this fragment
        return view;


    }

    @Override
    public void onStart() {
        super.onStart();

        //iniciar adaptador
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String mat=parent.getItemAtPosition(position).toString();
       // Toast.makeText(parent.getContext(),mat,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

}