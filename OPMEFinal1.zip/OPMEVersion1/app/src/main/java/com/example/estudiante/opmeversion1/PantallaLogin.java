package com.example.estudiante.opmeversion1;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class PantallaLogin extends AppCompatActivity {

    Button ingresar;

    EditText usuario;
    EditText contra;

    Typeface robotoBold,robotoRegular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login_page);
        ingresar = findViewById(R.id.btn_ingreso);

        usuario = findViewById(R.id.et_usuario);
        contra = findViewById(R.id.et_contra);


        robotoBold= Typeface.createFromAsset(this.getAssets(), "Fonts/robotoBold.ttf");
        robotoRegular= Typeface.createFromAsset(this.getAssets(), "Fonts/robotoRegular.ttf");

        ingresar.setTypeface(robotoBold);
        usuario.setTypeface(robotoRegular);
        contra.setTypeface(robotoRegular);


        ingresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent irPrincipal = new Intent(PantallaLogin.this, PantallaPrincipal.class);
                startActivity(irPrincipal);
                finish();
            }
        });



    }
}
