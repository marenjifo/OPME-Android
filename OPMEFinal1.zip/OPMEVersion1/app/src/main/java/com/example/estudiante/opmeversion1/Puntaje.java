package com.example.estudiante.opmeversion1;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class Puntaje extends AppCompatActivity {

    TextView tv_valor1;
    TextView tv_valor2;
    TextView tv_valor3;
    TextView tv_puntaje;
    private int scoreFinal;


    Button btn_terminar;

    Typeface robotoBold,robotoRegular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_puntaje);

        robotoBold= Typeface.createFromAsset(this.getAssets(), "Fonts/robotoBold.ttf");
        robotoRegular= Typeface.createFromAsset(this.getAssets(), "Fonts/robotoRegular.ttf");

        tv_valor1=findViewById(R.id.tv_valor1);
        tv_valor2=findViewById(R.id.tv_valor2);
        tv_valor3=findViewById(R.id.tv_valor3);
        tv_puntaje=findViewById(R.id.tv_puntaje);

        btn_terminar=findViewById(R.id.btn_terminar);


        tv_valor1.setTypeface(robotoBold);
        tv_valor2.setTypeface(robotoBold);
        tv_valor3.setTypeface(robotoBold);
        tv_puntaje.setTypeface(robotoBold);

        btn_terminar.setTypeface(robotoBold);

        scoreFinal= getIntent().getIntExtra("score",0);
        tv_puntaje.setText(scoreFinal+"");
    }
}
