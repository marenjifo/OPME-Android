package com.example.estudiante.opmeversion1;

import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseListAdapter;
import com.firebase.ui.database.FirebaseListOptions;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public class RecorFragment extends Fragment {

    private static final String TAG = "RecorFragment";
    private ListView lv_recor;
    FirebaseListAdapter<Recor> adapter;
    private FirebaseDatabase db;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_recor, container, false);

        lv_recor=view.findViewById(R.id.lv_recor);
        db=FirebaseDatabase.getInstance();


        //Lista de tareas
        Query ref=db.getReference().child("recordatorios");
        FirebaseListOptions<Recor> options = new FirebaseListOptions.Builder<Recor>().setLayout(R.layout.renglon_recor).setQuery(ref,Recor.class).build();

        adapter=new FirebaseListAdapter<Recor>(options) {
            @Override
            protected void populateView(@NonNull View v, @NonNull Recor model, int position) {

                ImageView iv_icon_tarea = v.findViewById(R.id.iv_icon_tarea);
                TextView tv_nombre = v.findViewById(R.id.tv_nombre);
                TextView tv_materia = v.findViewById(R.id.tv_materia);
                TextView tv_color = v.findViewById(R.id.tv_color);
                TextView tv_fecha = v.findViewById(R.id.tv_fecha);
                TextView tv_hora = v.findViewById(R.id.tv_hora);
                TextView tv_duracion = v.findViewById(R.id.tv_duracion);

                tv_nombre.setText(model.nombre);
                tv_materia.setText(model.materia);
                tv_fecha.setText(model.fecha);
                tv_hora.setText(model.hora);
                tv_duracion.setText(model.duracion + " horas");

                if (model.tipo != null) {

                    if (model.tipo.equals("Lectura")) {
                        iv_icon_tarea.setImageResource(R.drawable.libro_tareas);
                    }
                    if (model.tipo.equals("Video")) {
                        iv_icon_tarea.setImageResource(R.drawable.video_tareas);
                    }
                    if (model.tipo.equals("Taller")) {
                        iv_icon_tarea.setImageResource(R.drawable.taller_tareas);
                    }
                }
                    if (model.materia.equals("Algebra")) {
                        tv_color.setBackgroundResource(R.drawable.color_algebra);
                    }
                    if (model.materia.equals("Logica")) {
                        tv_color.setBackgroundResource(R.drawable.color_logica);
                    }
                    if (model.materia.equals("COE")) {
                        tv_color.setBackgroundResource(R.drawable.color_coe);
                    }

                }

        };

//Añadir el adaptador a la lista

        lv_recor.setAdapter(adapter);

        return view;


    }

    @Override
    public void onStart() {
        super.onStart();

        //iniciar adaptador
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}
